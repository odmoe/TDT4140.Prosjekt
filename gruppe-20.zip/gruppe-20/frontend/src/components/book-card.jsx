import {
  Card,
  Image,
  Group,
  Text,
  Badge,
  Button,
  Rating,
  Flex,
} from "@mantine/core";
import { useNavigate } from "react-router-dom";

export const BookCard = ({ book }) => {
  const navigate = useNavigate();
  return (
    <Card shadow="sm" p="lg" radius="md" withBorder>
      <Card.Section py="md">
        <Image
          style={{
            mixBlendMode: "multiply",
          }}
          fit="cover"
          withPlaceholder
          src={book.image || "/book-cover-placeholder.png"}
          alt="Book cover"
        />
      </Card.Section>
      <Group position="apart" mt="md" mb="xs">
        <Text weight={500}>{book.title}</Text>
        <Flex>
          <Rating
            defaultValue={book.averageRating ?? 0}
            fractions={10}
            readOnly
          />
          <span>({book.averageRating?.toFixed(2) ?? "0.00"})</span>
        </Flex>
        <Badge color="pink" variant="light">
          {book.release_year}
        </Badge>
      </Group>
      <Group py="sm">
        {book.authors.map((author) => (
          <Badge key={author.id} color="blue" variant="light">
            {author.name}
          </Badge>
        ))}
        {book.genres.map((genre) => (
          <Badge key={genre.id} color="green" variant="light">
            {genre.name}
          </Badge>
        ))}
      </Group>
      <Text size="sm" color="dimmed">
        {book.description || "Ingen beskrivelse oppgitt for denne boka."}
      </Text>
      <Button
        variant="light"
        color="blue"
        fullWidth
        mt="md"
        radius="md"
        onClick={() => navigate(`/books/${book.id}`)}
      >
        Se anmeldelser ({book.ratingCount})
      </Button>
    </Card>
  );
};
