INSERT OR IGNORE INTO authors (name, id) VALUES ('J. K. Rowling', 100), ('Stephen King', 101);
