INSERT OR IGNORE INTO genres (name, id) VALUES ('Horror', 100), ('Fantasy', 101);
